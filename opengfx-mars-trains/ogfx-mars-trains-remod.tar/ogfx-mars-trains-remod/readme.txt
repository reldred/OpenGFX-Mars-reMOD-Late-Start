OpenGFX Mars Trains 
-------------------

Contents:

1 About
2 Usage
3 Contributing and reporting bugs
4 Credits
5 License



-------
1 About
-------

This NewGRF provides a Martian Trains

Name of this Repo:  OpenGFX Mars Trains - reMOD Late Start
Repository version: 0



-------
2 Usage
-------

Just add the NewGRF to the selection of active NewGRFs within the
configuration window as accessible from the main menu.



---------------------------------
3 Contributing and reporting bugs
---------------------------------

The issue tracker is located at the #openttdcoop DevZone at
    http://dev.openttdcoop.org/projects/opengfx-mars-trains

The complete source code is available as mercurial checkout via
    hg clone http://hg.openttdcoop.org/opengfx-mars



---------
4 Credits
---------

Author:   Zephyris
Graphics: Zephyris



---------
5 License
---------

OpenGFX Mars Zephyris
Copyright (C) 2014 Zephyris, planetmaker and others
Contact: planetmaker@openttd.org

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
